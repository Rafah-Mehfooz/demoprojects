<!DOCTYPE html>
<html lang="en"  >

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Scrolling Nav - Start Bootstrap Template</title>

    <!-- Bootstrap Core CSS -->
		<link href="css/bootstrap.css" rel="stylesheet">
		<link href="css/font-awesome.css" rel="stylesheet">

    <!-- Custom CSS -->
		<link href="css/scrolling-nav.css" rel="stylesheet">
		<link href="css/custom.css" rel="stylesheet">
	 
	 <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    <!-- Scrolling Nav JavaScript -->
    <script src="js/jquery.easing.min.js"></script>
    <script src="js/scrolling-nav.js"></script>


	
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
	<script src="js/custom.js" type="text/javascript"></script>	
	<script type="text/javascript" src="js/jquery-1.11.0.min.js"></script>
	<script type="text/javascript" src="js/jquery.validate.min.js"></script>
	<script type="text/javascript">
		$(document).ready(function() {
				
			// jQuery Validation
			$("#signup").validate({
				// if valid, post data via AJAX
				submitHandler: function(form) {
					$.post("subscribe.php", { fname: $("#fname").val(), lname: $("#lname").val(), email: $("#email").val(), wname: $("#wname").val() }, function(data) {
						$('#response').html(data);
					});
				
					
				},
				// all fields are required
				rules: {
					fname: {
						required: true
					},
					lname: {
						required: true
					},
					email: {
						required: true,
						email: true
					},
					wname: {
						required: true
					}
				}
			});
			
				});

		$(document).ready(function() {
			//Second form
		$("#signup2").validate({
				// if valid, post data via AJAX
				submitHandler: function(form) {
				//	alert($("#ffname").val());
					$.post("subscribe.php", { fname: $("#ffname").val(), lname: $("#llname").val(), email: $("#eemail").val(), wname: $("#wwname").val() }, function(data) {
						$('#response2').html(data);
					});
				
					
				},
				// all fields are required
				rules: {
					fname: {
						required: true
					},
					lname: {
						required: true
					},
					email: {
						required: true,
						email: true
					},
					wname: {
						required: true
					}
				}
			});
		
		
		
		
		});
		
	</script>

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>


<body id="page-top" data-spy="scroll" data-target=".navbar-fixed-top">

    <!-- ******************Navigation for scrolling FIXED TOP **************** -->
	
    <nav class="navbar navbar-default navbar-fixed-top" role="navigation">
        <div class="container">
			<div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand page-scroll" href="#page-top"></a>
            </div>
			
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav">
                    <!-- Hidden li included to remove active class from about link when scrolled up past about section -->
                    <li class="hidden">
                        <a class="page-scroll" href="#page-top"></a>
                    </li>
                    <li>
                        <a class="page-scroll" href="#monetization">MONETIZATION</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="#tools">TOOLS</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="#brands">BRANDS</a>
                    </li>
					<li>
                        <a class="page-scroll" href="#api">API</a>
                    </li>
					<li>
                        <a class="page-scroll" href="#analytics">ANALYTICS</a>
                    </li>
                </ul>
            </div>
			
           
        </div>
		<a class="page-scroll link sign-up-button btn btn-default"  href="#page-top" >SIGN UP</a>
    </nav>

	    <!-- ****************** TOP FULL SCREEN SECTION **************** -->
	
	
    <section id="intro" class="intro-section full">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
					<i class="logo"></i>
                    <h1 class="heading-scope">MONETIZE YOUR INFLUENCE</h1>
					
					<form class="formee news-letter-form" id="signup" action="subscribe.php" method="post">
						
						<div class="input-fields">
							<input 	required="" class="email-field 	  ng-invalid-required" name="email" id="email"  placeholder="Email Address" ng-required="true" type="email"		>
							<input 	required="" class="username-field ng-invalid-required" name="fname" id="fname" 	placeholder="First Name"  	ng-required="true" type="text"		>
							<input  required="" class="lastname-field ng-invalid-required" name="lname" id="lname"  placeholder="Last Name"   	ng-required="true" type="text"		>	
							<input  required="" class="web-field	  ng-invalid-required" name="wname" id="wname"  placeholder="Website"  		ng-required="true" type="text"	>	

						</div>
						<button class="right inputnew sign-up-top-button text-scope" type="submit"  ng-click="signup()" translate="" >Sign Up</button>														
					</form>
					<div id="response"></div>
					
					<div class="actions-information ">Already have an account? <a href="#" translate="" >Log in here</a></div>
					<div class="legal-requirements text-scope" ng-bind-html="legalMessage">By entering your email address, you are agreeing to our 
					<a href="#" target="_blank" >Terms of Service</a>, 
					<a href="#" target="_blank">Privacy Policy</a>, and to receive emails from POPSUGAR Inc. (owner and operator of ShopStyle Collective).
					</div>
                   
                </div>
				<div><a class="btn btn-default page-scroll scroll-down-page" href="#monetization"><i class="fa fa-angle-down icon-menu-caret"></i></a></div>
            </div>
        </div>
    </section>
	
	
	  <!-- ******************Navigation BOTTOM FIXED **************** -->
	
	
	<nav class="navbar navbar-default navbar-fixed-bottom" role="navigation">
        <div class="container">
         <div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand page-scroll" href="#page-top"></a>
            </div>   
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav">
          
                    <li class="hidden">
                        <a class="page-scroll" href="#page-top"></a>
                    </li>
                    <li>
                        <a class="page-scroll" href="#monetization">MONETIZATION</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="#tools">TOOLS</a>
                    </li>
                      <li>
                        <a class="page-scroll" href="#brands">BRANDS</a>
                    </li>
					<li>
                        <a class="page-scroll" href="#api">API</a>
                    </li>
					<li>
                        <a class="page-scroll" href="#analytics">ANALYTICS</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
	
		  <!-- ******************CONTENTS UNDER BOTTOM FIXED NAVBAR **************** -->
	
	
	<div class="big-wrapper">
		<section id="monetization" class="monetization-section all-sections">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<div>
							<h1 class="heading1">MONETIZE EVERYTHING</h1>
							<p class="scope">Use our affiliate links to monetize your influence across your blog and every social platform: Facebook, Pinterest, Twitter, video, and Instagram!</p>
						</div>
						
						<div class="top-image-monetize">
							<img src="img/graphic-monetize.png">
							
						</div>
						
						<div class="monetization-detail">
							<div class="monetization-detail-copy">
								<div class="icon-container"><i class="fa fa-instagram "></i></div>
								<h3 translate="" class="heading3">ShopStyle.it</h3>
								<p translate="" class="para-scope">With ShopStyle.it, Instagrammers who “like” your photos will receive a shoppable email detailing your full look.</p>
							</div>
							
							<div class="monetization-detail-copy">
								<div class="icon-container"><i class="fa fa-facebook"></i> <i class="fa fa-pinterest"></i><i class="fa fa-twitter"></i></div>
								<h3 translate="" class="heading3">Social Media</h3>
								<p translate="" class="para-scope" >Post your favorite products to Facebook, Pinterest, and Twitter. Get paid when your followers shop.</p>
							</div>
							
							<div class="monetization-detail-copy">
								<div class="icon-container"><i class="fa fa-joomla"></i> <i class="fa fa-wordpress"></i><i class="fa fa-plus"></i></div>
								<h3 translate="" class="heading3">BLOG YOUR STYLE</h3>
								<p translate="" class="para-scope" >Produce and publish custom content with our specialized tools — optimized for every CMS, even video players.</p>
							</div>
						</div>
				   </div>
				   <div><a class="btn btn-default page-scroll scroll-down-page" href="#tools"><i class="fa fa-angle-down icon-menu-caret"></i></a></div>
				</div>
			</div>
		</section>

		<section id="tools" class="tools-section">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<div class="tools-image">
							<img src="img/graphic-bookmarklet.png">
						</div>

						<div class="tools-detail-copy">
							<h1 translate="" class="heading1" >Utilize Content Creation Tools</h1>
							<p translate="" class="para-scope" >Use helpful tools like LinkIt, customizable widgets, and video-tagging technology to engage your audience and build shoppable content.</p>
						</div>
				   </div>
				   <div><a id="brand-down" class="btn btn-default page-scroll scroll-down-page" href="#brands"><i class="fa fa-angle-down icon-menu-caret"></i></a></div>
				</div>
			</div>
		</section>
		
		<section id="brands" class="brands-section">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">

						<div class="brands-image">
							<img src="img/graphic-brands.png">
						</div>
						
						<div class="brands-detail-copy">
							<h1 translate="" class="heading1" >Partner With Thousands of Brands</h1>
							<p translate="" class="para-scope" >Harness the power of ShopStyle and take advantage of competitive affiliate rates with your favorite brands and retailers.</p>
							
						</div>
						
						
					</div>
					<div><a id="brand-down" class="btn btn-default page-scroll scroll-down-page" href="#api"><i class="fa fa-angle-down icon-menu-caret"></i></a></div>
				</div>
			</div>
		</section>
		
		<section id="api" class="api-section">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						
						<div class="api-image">
							<img src="img/graphic-api-products.png">
						</div>
						
						<div class="api-detail-copy">
							<h1 translate="" class="heading1">Access Our API</h1>
							<p translate="" class="para-scope">Attention, developers! Building a shopping platform? Use the same API that powers ShopStyle.com as well as ShopStyle’s apps to access thousands of brands and millions of products.</p>
						</div>
						
						
					</div>
					<div><a class="btn btn-default page-scroll scroll-down-page" href="#analytics"><i class="fa fa-angle-down icon-menu-caret"></i></a></div>
				</div>
			</div>
		</section>
		
		<section id="analytics" class="analytics-section">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<div class="analytics-image">
							<img  src="img/graphic-analytics-view.png">
						</div>
						
						<div class="analytics-detail-copy">
							<h1 translate="" class="heading1">Optimize With Personalized Analytics</h1>
							<p translate="" class="para-scope">Track performance, earned revenue, and highest-converting products through your own dashboard.</p>
						</div>
					</div>
				</div>
			</div>
		</section>
	</div>
	
	<div class="sign-in-bottom">
		<h3 id="bottom-heading">SIGN UP</h3>
			<form class="formee news-letter-form" id="signup2" action="subscribe.php" method="post">
							
								
				<div class="input-fields">
					<input 	required="" class="email-field 	  ng-invalid-required" name="email" id="eemail"  placeholder="Email Address" ng-required="true" type="email"		>
					<input 	required="" class="username-field ng-invalid-required" name="fname" id="ffname" 	placeholder="First Name"  	ng-required="true" type="text"		>
					<input  required="" class="lastname-field ng-invalid-required" name="lname" id="llname"  placeholder="Last Name"   	ng-required="true" type="text"		>	
					<input  required="" class="web-field	  ng-invalid-required" name="wname" id="wwname"  placeholder="Website"  		ng-required="true" type="text"	>	

				</div>
			<button class="right inputnew sign-up-top-button text-scope" type="submit"  ng-click="signup()" translate="" >Sign Up</button>
			</form>
			<div id="response2"></div>
			<div class="actions-information ">Already have an account? <a href="#" translate="" >Log in here</a></div>
			<div class="legal-requirements text-scope " ng-bind-html="legalMessage">By entering your email address, you are agreeing to our 
				<a href="#" target="_blank" >Terms of Service</a>, 
				<a href="#" target="_blank">Privacy Policy</a>, and to receive emails from POPSUGAR Inc. (owner and operator of ShopStyle Collective).
			</div>
	</div>

		  <!-- ****************** FOOTER **************** -->

	<footer class="footer-fullscreen text-scope">
		
		<a class="text-scope" href="#" translate="">API</a> 
		<a class="text-scope" href="#" translate="">Help &amp; FAQ</a>
		<a class="text-scope" href="#" translate="">Privacy</a>
		<a class="text-scope" href="#" translate="">Contact</a>
		<a class="text-scope" href="#" translate="">Terms</a> 
		
		
	</footer>

</body>

</html>
